﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class insObj : MonoBehaviour {

	public GameObject createball;
	// Use this for initialization
	void Start () {
		Invoke ("spawnobject", 3);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void spawnobject(){
		Instantiate (createball);
		Start ();
	}
}
