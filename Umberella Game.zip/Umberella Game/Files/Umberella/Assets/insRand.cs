﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class insRand : MonoBehaviour {

	public GameObject[] myobjects;
	static int score;
	public Text myscore;
	// Use this for initialization
	void Start () {
		Invoke ("createobjects",5);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void createobjects()
	{
		Instantiate (myobjects [Random.Range (0, 2)], transform.position, transform.rotation);
		Start ();
	}
	public void incscore(){
		score=score+1;
		myscore.text=score.ToString();
	}
}
