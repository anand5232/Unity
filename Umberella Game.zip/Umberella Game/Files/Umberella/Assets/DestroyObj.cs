﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyObj : MonoBehaviour {
	insRand _inst;
	// Use this for initialization
	void Start () {
		_inst = GameObject.FindGameObjectWithTag ("_inst").GetComponent<insRand> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void OnMouseDown(){
		_inst.SendMessage ("incscore");
		Destroy (gameObject);	
	}

}
