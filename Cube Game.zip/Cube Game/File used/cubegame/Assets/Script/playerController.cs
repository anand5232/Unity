﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class playerController : MonoBehaviour {
    
     private Rigidbody rb;
     public float speed;
     private int Health;
     public Text countText;
     public Text DieText;
     
	// Use this for initialization
	void Start() {
        rb=GetComponent<Rigidbody>();
        Health=6;
        SetCountText();
        DieText.text="";
    }
    void FixedUpdate()
    {
        float moveHorizontal=Input.GetAxis("Horizontal");
        float moveVertical=Input.GetAxis("Vertical");
        
        Vector3 movement = new Vector3(moveHorizontal,0.0f,moveVertical);
        rb.AddForce(movement*speed);
        
    }
	

    void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.CompareTag("Pick Up"))
        {   
            other.gameObject.SetActive(false);
            Health=Health-1;
            SetCountText();
            
            
            
        }
    } 
    
    void SetCountText()
    {
        countText.text="Health"+Health.ToString();
        if(Health==0)
        {
            Destroy(gameObject);
            DieText.text="You Died";
        }
    }
    
  
}
